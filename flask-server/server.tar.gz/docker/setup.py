from website import run_docker
import os


def main():
    options()
    chose()


def options():
    print('''
---------------------------------    
|    1.Install CGI server       |
|    2.Run this Application.    |
---------------------------------
''')


def chose():
    choose = int(input('Choose one to execute:'))
    if choose == 1:
        run_docker()
    elif choose == 2:
        os.system('python3 main.py')


if __name__ == '__main__':
    main()
