def getip():
    IP = '0.0.0.0'
    return IP
