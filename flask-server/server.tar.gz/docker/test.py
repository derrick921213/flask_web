#import requests
#sum = 'sdfkjeiqwijdij38489feiwj3r89udvjis4htih8vys804hdsh8y8ehw3r893987544651454+46565-8487215ekhgeuihouoawuhdhahoiwhd9pwhegqhwdnjsklallq'
#url = 'http://0.0.0.0:5000/get_token/'+sum
#r = requests.get(url)
# if r.status_code == requests.codes.ok:
#    print(r.text)
A = 1


def Sum(X, Y):
    global tmp
    tmp = X + Y
    # return tmp


# 呼叫並使用Function
Sum(5, 6)

print("tmp值為：", tmp)
